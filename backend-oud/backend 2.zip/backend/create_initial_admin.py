import asyncio
import uuid
from datetime import datetime

# Import necessary parts from server.py
# Assuming server.py is in the same directory or adjust path accordingly
from server import (
    UserDb,
    AsyncSessionLocal,
    async_engine,
    Base,
    get_password_hash,
    USER_ROLES
)

# --- CONFIGURATION FOR THE INITIAL ADMIN USER ---
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "adminpass123"  # Choose a strong password!
ADMIN_CLASS_CODE = "ADMIN_CLASS"
# -------------------------------------------------

async def create_tables():
    async with async_engine.begin() as conn:
        # await conn.run_sync(Base.metadata.drop_all) # Uncomment to drop tables first
        await conn.run_sync(Base.metadata.create_all)
    print("Database tables created (if they didn't exist).")

async def add_initial_admin():
    async with AsyncSessionLocal() as session:
        async with session.begin():
            # Check if admin user already exists
            from sqlalchemy import select
            result = await session.execute(select(UserDb).where(UserDb.username == ADMIN_USERNAME))
            existing_admin = result.scalars().first()

            if existing_admin:
                print(f"Admin user '{ADMIN_USERNAME}' already exists. Skipping creation.")
                return

            hashed_password = get_password_hash(ADMIN_PASSWORD)
            admin_user = UserDb(
                id=str(uuid.uuid4()),
                username=ADMIN_USERNAME,
                password_hash=hashed_password,
                class_code=ADMIN_CLASS_CODE,
                role=USER_ROLES["ADMIN"],
                points=0,
                level=1,
                badges=[],
                streak_days=0,
                last_entry_date=None,
                created_at=datetime.utcnow()
            )
            session.add(admin_user)
            await session.commit()
            print(f"Admin user '{ADMIN_USERNAME}' created successfully!")
            print(f"Username: {ADMIN_USERNAME}")
            print(f"Password: {ADMIN_PASSWORD} (This is the one you set in the script)")
            print("You can now log in with these credentials.")

async def main():
    await create_tables() # Ensure tables exist
    await add_initial_admin()

if __name__ == "__main__":
    print("Starting script to create initial admin user...")
    asyncio.run(main())
    print("Script finished.")
